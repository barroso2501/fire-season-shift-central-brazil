# Comandos para subir ao GitHub

> Guia para registrar este repositório no GitHub assim que seu acesso for liberado.
> Não é parte do projeto científico — pode apagar este arquivo depois, ou mantê-lo como nota.

## Passo 1 — Criar o repositório no GitHub (pela interface web)

1. Acesse https://github.com/new
2. **Repository name:** `fire-season-shift-central-brazil`
3. **Visibility:** **Private** (recomendado até a submissão do manuscrito)
4. **NÃO** marque "Add a README", "Add .gitignore" nem "Choose a license" —
   este pacote já traz os três. Marcar criaria conflito.
5. Clique em **Create repository**. Anote a URL que aparece, algo como:
   `https://github.com/SEU-USUARIO/fire-season-shift-central-brazil.git`

## Passo 2 — Enviar os arquivos (pelo terminal)

Abra o terminal **dentro da pasta** `fire-season-shift-central-brazil` (a que contém o
README.md) e cole os comandos abaixo, um bloco de cada vez.

```bash
# inicializa o repositório local
git init
git branch -M main

# adiciona todos os arquivos
git add .

# primeiro commit
git commit -m "Initial commit: fire-season displacement analysis with ENSO robustness"

# conecta ao repositório remoto que você criou no Passo 1
# >>> troque SEU-USUARIO pelo seu nome de usuário do GitHub <<<
git remote add origin https://github.com/SEU-USUARIO/fire-season-shift-central-brazil.git

# envia
git push -u origin main
```

Na primeira vez o GitHub vai pedir autenticação. Se pedir usuário e senha e a senha não
funcionar, é porque o GitHub não aceita mais senha comum no terminal — use um **Personal Access
Token** no lugar da senha:
- Gere em: https://github.com/settings/tokens → "Generate new token (classic)" → marque o escopo
  `repo` → copie o token e cole no lugar da senha quando o terminal pedir.

## Passo 3 — Conferir

Recarregue a página do repositório no navegador. Devem aparecer o README renderizado na home, e as
pastas `data/`, `docs/`, `notebooks/`, `outputs/`.

## Alternativa sem terminal (arrastar e soltar)

Se preferir não usar o terminal:
1. Crie o repositório (Passo 1), **desta vez deixando-o vazio**.
2. Na página do repositório, clique em **"uploading an existing file"**.
3. Arraste a pasta inteira (ou os arquivos) para a área de upload.
4. Escreva uma mensagem de commit e clique em **Commit changes**.

> Observação: o arrastar-e-soltar da web não preserva pastas vazias. A pasta `outputs/` só
> aparecerá se o arquivo `.gitkeep` dentro dela for enviado junto — ele já está no pacote, então
> selecione-o no upload.

## Quando for tornar público (na submissão)

Settings → General → role até "Danger Zone" → **Change visibility** → Public.
Para um DOI citável, conecte o repositório ao **Zenodo** (https://zenodo.org) antes de criar uma
*release* — o Zenodo gera um DOI automático para cada release, que vai na seção de disponibilidade
de dados do manuscrito.
